# -*- coding: utf-8 -*-
__author__ = "Romain Thomas"
__credits__ = "Romain Thomas"
__license__ = "GNU GPL v3"
__version__ = "0.1.9"
__maintainer__ = "Romain Thomas"
__email__ = "the.spartan.proj@gmail.com"
__status__ = "Development"
__website__ = "https://astrom-tom.github.io/Photon/build/html/index.html" 
